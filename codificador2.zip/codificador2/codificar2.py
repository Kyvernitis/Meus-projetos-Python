def codificar():
    """Codifica um arquivo de texto."""
    lista = [['a', '!'], ['b', '@'], ['c', '#'], ['d', '$'], ['e', '%'],
             ['f', '&'], ['g', '*'], ['h', '+'], ['i', '^'], ['j', '<'],
             ['k', '>'], ['l', ';'], ['m', '/'], ['n', '°'], ['o', '?'],
             ['p', '|'], ['q', ','], ['r', '('], ['s', ')'], ['t', '{'],
             ['u', '}'], ['w', '['], ['x', ']'], ['y', '~'], ['z', ':'],
             [' ', '_']]
    
    arq = open('codificador2/mensagem.txt', 'r')
    mensagem = arq.readlines()
    arq.close()
    print(mensagem)
    mensagem_codificada = []
    for linha in mensagem:
        mensagem1 = ''
        for letra in linha:
            for caractere in lista:
                if letra.lower() in caractere[0]:
                    mensagem1 += caractere[1]
        print(mensagem1)
        mensagem_codificada.append(mensagem1 + '\n')
    
    arquivo_codificado = open('codificador2/codificado.txt', 'a')
    arquivo_codificado.writelines(mensagem_codificada)
    arquivo_codificado.close()
    


codificar()    
